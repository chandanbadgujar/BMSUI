import React, {Component} from 'react';
 
export default class Header extends Component {
    render(){
        return (
            <div className='container'>
                <div className='card mt4'>
                    <div className='card-body'>
                        Header
                    </div>
                </div>
            </div>
        )
    }
}