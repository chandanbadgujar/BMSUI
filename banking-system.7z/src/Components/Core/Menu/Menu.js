import React, {Component} from 'react';

export default class Menu extends Component {
    render(){
        return (
            <div className='container'>
                <div className='card mt4'>
                    <div className='card-body'>
                        Menu
                    </div>
                </div>
            </div>
        )
    }
}