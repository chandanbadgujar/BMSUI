import React, { Component } from 'react';
import './style.css';

class Home extends Component {

    render() {
        return (
            <div className='container'>
                <div className='card mt4'>
                    <div className='card-body'>
                        Home
                    </div>
                </div>
            </div>
        );
    }
}

export default Home;