
export const registerUser = () => {
    return {type : 'REGISTER_USER' };
};